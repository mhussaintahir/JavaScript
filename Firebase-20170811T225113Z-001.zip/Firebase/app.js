


// alert("Hello Firebase");




var database=firebase.database().ref('/');
function demo(){

    var user ={
        name: 'abdul Rehman'
    }
database.child('batch42').push(user);
}